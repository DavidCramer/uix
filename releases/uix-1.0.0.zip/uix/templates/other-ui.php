
<input type="text" name="location" value="{{location}}">