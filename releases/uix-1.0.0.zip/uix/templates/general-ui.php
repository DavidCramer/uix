<table class="form-table">
	<tbody>
		<tr>
			<th scope="row">
				<label for="example">Example Setting</label>
			</th>
			<td>
				<input type="text" class="regular-text" value="{{example}}" id="example" name="example">
			</td>
		</tr>
	</tbody>
</table>
